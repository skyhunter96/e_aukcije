<footer class="footer text-center">
    e-aukcije kontrolna tabla verzija XXXXXXX | Podrška <a href="http://alek.online">Alek.online</a>.
</footer>