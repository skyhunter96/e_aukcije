<footer id="tg-footer" class="tg-footer tg-footereight tg-haslayout">
    <div class="container">
        <div class="row">
            <div class="tg-footercolumns">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="tg-fcol">
                        <div class="tg-footercolumntitle">
                            <h3>O nama</h3>
                        </div>
                        <div class="tg-aboutyourshop">
                            <div class="tg-description">
                                <p>Consectetur adipisicing elit sed do eiaod tempor incididunt ut labore dolorg atsna aliqua enim ad minim veniam quis norud exercitation ullamco laboris nisi utliquip ex ea commodo consequat aute irurelor reprehenderit in voluptate velit esseillum dolore eu fugiat nulla.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="tg-fcol">
                        <div class="tg-footercolumntitle">
                            <h3>Minim veniam</h3>
                        </div>
                        <ul class="tg-discountbrands">
                            <li><a href="#">Adipisicing elit</a></li>
                            <li><a href="#">Sed do eiusmod</a></li>
                            <li><a href="#">Tempor incididunt</a></li>
                            <li><a href="#">Labore et dolore magna</a></li>
                            <li><a href="#">Aliqua enim ad</a></li>
                            <li><a href="#">Minim veniam</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="tg-fcol">
                        <div class="tg-footercolumntitle">
                            <h3>Brzi linkovi</h3>
                        </div>
                        <ul class="tg-quicklinks">
                            <li><a href="#">Moj profil</a></li>
                            <li><a href="#">Istorija narudžbina</a></li>
                            <li><a href="#">Moja lista želja</a></li>
                            <li><a href="#">Informacije o isporuci</a></li>
                            <li><a href="#">Mapa sajta</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="tg-fcol">
                        <div class="tg-footercolumntitle">
                            <h3>Stupite u kontakt</h3>
                        </div>
                        <div class="tg-description">
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing diam nonummy.</p>
                        </div>
                        <ul class="tg-contactinfo">
                            <li>
                                <i class="fa fa-map-marker"></i>
                                <address>Nikole Tesle 10 14814 Beograd</address>
                            </li>
                            <li>
                                <i class="fa fa-mobile-phone"></i>
                                <span>+381 61 123 1234</span>
                            </li>
                            <li>
                                <i class="fa fa-paper-plane"></i>
                                <span><a href="podrska@e-aukcije.rs">podrska@e-aukcije.rs</a></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="tg-footerbottombar">
        <div class="container">
            <div class="row">
                <p class="tg-copyrights">© 2018 | Sva prava zadržana</p>
                <nav class="tg-footernav">
                    <ul>
                        <li><a href="#">Često pitana pitanja</a></li>
                        <li><a href="#">Vraćanje proizvoda</a></li>
                        <li><a href="#">Sitemap</a></li>
                    </ul>
                </nav>
                <strong class="tg-logo">
                    <a href="#"><img src="{{ asset('') }}pics/product1/images/logo2.png" alt="image description"></a>
                </strong>
            </div>
        </div>
    </div>
</footer>