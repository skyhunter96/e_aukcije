@extends('layouts.front')

@section('content')

    <a href="{{ asset('/users') }}" >Korisnici</a><br><br>

@endsection