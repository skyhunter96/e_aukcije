<?php include 'php/inc/head.inc'?>
		<main id="tg-main" class="tg-main tg-haslayout">
			<div class="tg-main-section tg-haslayout">
				<div class="container">
					<div class="row">
						<div id="tg-content" class="tg-content">
							<div class="tg-sectionhead">
								<div class="col-sm-7 col-xs-12">
									<div class="tg-sectiontitle">
										<h2><span>potrebna vam je pomoć?
										</span>tu smo za vas<em></em></h2>
										<span class="tg-lighttitle"><span>from our</span>latest blogs<em></em></span>
									</div>
								</div>

							</div>
							<div class="tg-blogposts tg-bloggridv2">
								<div class="col-md-4 col-sm-6 col-xs-6">
									<article class="tg-post">
										<figure class="tg-featuredimg">
											<a href="#"><img src="images/blog.jpg" alt="image description"></a>
										</figure>
										<div class="tg-postcontent">

											<div class="tg-postheading">
												<h2><a href="#">sed do eiusmod tempor</a></h2>
											</div>
											<ul class="tg-postmatadata">
												<li><a href="#">By: admin</a></li>
												<li><a href="#"><time datetime="2016-09-10">june 27, 2016</time></a></li>
												<li><a href="#">03 Comments</a></li>
											</ul>
										</div>
									</article>
								</div>
								<div class="col-md-4 col-sm-6 col-xs-6">
									<article class="tg-post">
										<figure class="tg-featuredimg">
										<a href="#"><img src="images/blog.jpg" alt="image description"></a>
										</figure>
										<div class="tg-postcontent">
											<div class="tg-postheading">
												<h2><a href="#">sed do eiusmod tempor</a></h2>
											</div>
											<ul class="tg-postmatadata">
												<li><a href="#">By: admin</a></li>
												<li><a href="#"><time datetime="2016-09-10">june 27, 2016</time></a></li>
												<li><a href="#">03 Comments</a></li>
											</ul>
										</div>
									</article>
								</div>
								<div class="col-md-4 col-sm-6 col-xs-6">
									<article class="tg-post">
										<figure class="tg-featuredimg">
										<a href="#"><img src="images/blog.jpg" alt="image description"></a>
										</figure>
										<div class="tg-postcontent">

											<div class="tg-postheading">
												<h2><a href="#">sed do eiusmod tempor</a></h2>
											</div>
											<ul class="tg-postmatadata">
												<li><a href="#">By: admin</a></li>
												<li><a href="#"><time datetime="2016-09-10">june 27, 2016</time></a></li>
												<li><a href="#">03 Comments</a></li>
											</ul>
										</div>
									</article>
								</div>
								<div class="col-md-4 col-sm-6 col-xs-6">
									<article class="tg-post">
										<figure class="tg-featuredimg">
										<a href="#"><img src="images/blog.jpg" alt="image description"></a>
										</figure>
										<div class="tg-postcontent">

											<div class="tg-postheading">
												<h2><a href="#">sed do eiusmod tempor</a></h2>
											</div>
											<ul class="tg-postmatadata">
												<li><a href="#">By: admin</a></li>
												<li><a href="#"><time datetime="2016-09-10">june 27, 2016</time></a></li>
												<li><a href="#">03 Comments</a></li>
											</ul>
										</div>
									</article>
								</div>
								<div class="col-md-4 col-sm-6 col-xs-6">
									<article class="tg-post">
										<figure class="tg-featuredimg">
										<a href="#"><img src="images/blog.jpg" alt="image description"></a>
										</figure>
										<div class="tg-postcontent">

											<div class="tg-postheading">
												<h2><a href="#">sed do eiusmod tempor</a></h2>
											</div>
											<ul class="tg-postmatadata">
												<li><a href="#">By: admin</a></li>
												<li><a href="#"><time datetime="2016-09-10">june 27, 2016</time></a></li>
												<li><a href="#">03 Comments</a></li>
											</ul>
										</div>
									</article>
								</div>
								<div class="col-md-4 col-sm-6 col-xs-6">
									<article class="tg-post">
										<figure class="tg-featuredimg">
										<a href="#"><img src="images/blog.jpg" alt="image description"></a>
										</figure>
										<div class="tg-postcontent">

											<div class="tg-postheading">
												<h2><a href="#">sed do eiusmod tempor</a></h2>
											</div>
											<ul class="tg-postmatadata">
												<li><a href="#">By: admin</a></li>
												<li><a href="#"><time datetime="2016-09-10">june 27, 2016</time></a></li>
												<li><a href="#">03 Comments</a></li>
											</ul>
										</div>
									</article>
								</div>
								<div class="col-md-4 col-sm-6 col-xs-6">
									<article class="tg-post">
										<figure class="tg-featuredimg">
										<a href="#"><img src="images/blog.jpg" alt="image description"></a>
										</figure>
										<div class="tg-postcontent">

											<div class="tg-postheading">
												<h2><a href="#">sed do eiusmod tempor</a></h2>
											</div>
											<ul class="tg-postmatadata">
												<li><a href="#">By: admin</a></li>
												<li><a href="#"><time datetime="2016-09-10">june 27, 2016</time></a></li>
												<li><a href="#">03 Comments</a></li>
											</ul>
										</div>
									</article>
								</div>
								<div class="col-md-4 col-sm-6 col-xs-6">
									<article class="tg-post">
										<figure class="tg-featuredimg">
										<a href="#"><img src="images/blog.jpg" alt="image description"></a>
										</figure>
										<div class="tg-postcontent">

											<div class="tg-postheading">
												<h2><a href="#">sed do eiusmod tempor</a></h2>
											</div>
											<ul class="tg-postmatadata">
												<li><a href="#">By: admin</a></li>
												<li><a href="#"><time datetime="2016-09-10">june 27, 2016</time></a></li>
												<li><a href="#">03 Comments</a></li>
											</ul>
										</div>
									</article>
								</div>
								<div class="col-md-4 col-sm-6 col-xs-6">
									<article class="tg-post">
										<figure class="tg-featuredimg">
										<a href="#"><img src="images/blog.jpg" alt="image description"></a>
										</figure>
										<div class="tg-postcontent">
											<div class="tg-postheading">
												<h2><a href="#">sed do eiusmod tempor</a></h2>
											</div>
											<ul class="tg-postmatadata">
												<li><a href="#">By: admin</a></li>
												<li><a href="#"><time datetime="2016-09-10">june 27, 2016</time></a></li>
												<li><a href="#">03 Comments</a></li>
											</ul>
										</div>
									</article>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</main>
		<!--************************************
				Main End
		*************************************-->
		<!--************************************
				Footer Start
		*************************************-->
		<?php include'php/inc/footer.inc'?>
		<!--************************************
				Footer End
		*************************************-->
	</div>
	<!--************************************
			Wrapper End
	*************************************-->
	<!--************************************
			Search Start
	*************************************-->

	<!--************************************
			Search End
	*************************************-->
	<script src="js/vendor/jquery-library.js"></script>
               <script src="js/vendor/bootstrap.min.js"></script>
               <script src="http://maps.google.com/maps/api/js?key=AIzaSyDlh_AGFXk44DuUVd6BDFas5XgqevprVms&language=en"></script>
               <script src="js/customScrollbar.min.js"></script>
               <script src="js/jquery.easings.min.js"></script>
               <script src="js/scrolloverflow.min.js"></script>
               <script src="js/jquery.fullPage.js"></script>
               <script src="js/jquery.countdown.js"></script>
               <script src="js/owl.carousel.min.js"></script>
               <script src="js/isotope.pkgd.js"></script>
               <script src="js/packery-mode.js"></script>
               <script src="js/prettyPhoto.js"></script>
               <script src="js/jquery-ui.js"></script>
               <script src="js/parallax.js"></script>
               <script src="js/countTo.js"></script>
               <script src="js/hoverdir.js"></script>
               <script src="js/appear.js"></script>
               <script src="js/gmap3.js"></script>
               <script src="js/main.js"></script>
            </body>
         </html>