<?php include 'php/inc/head.inc'?>
		<main id="tg-main" class="tg-main tg-haslayout">
			<div class="tg-main-section tg-haslayout">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 col-xs-12">
							<div id="tg-content" class="tg-content">
								<div class="tg-faqs">
									<div class="tg-sectionhead">
									<div class="tg-sectiontitle">
										<h2><span>često postavljena</span>pitanja(Č.P.P.)<em></em></h2>
										<span class="tg-lighttitle"><span>frequently</span>asked questions<em></em></span>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="row">
											<div class="tg-description">
												<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incunt ut labore et dolore magna aliqua tebaenim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
											</div>
										</div>
									</div>
								</div>
									<div id="tg-accordion" class="tg-accordian" role="tablist" aria-multiselectable="true">
										<div class="tg-panel">
											<h4 class="active">Adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua?</h4>
											<div class="tg-panelcontent" style="display: block;">
												<div class="tg-description">
													<img class="tg-alignleft" src="./cpp_files/img-07.jpg" alt="image description">
													<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam.</p>
													<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
												</div>
											</div>
										</div>
										<div class="tg-panel">
											<h4>Ut enim ad minim veniam, quis nostrud exercitation ullamco?</h4>
											<div class="tg-panelcontent" style="display: none;">
												<div class="tg-description">
													<p>Eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco laris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eugiat nulla pariatur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum ut perspictis unde omnis iste natus error sit voluptatem accusantium.</p>
												</div>
											</div>
										</div>
										<div class="tg-panel">
											<h4>Laboris nisi ut aliquip ex ea commodo consequat aute irure dolor?</h4>
											<div class="tg-panelcontent" style="display: none;">
												<div class="tg-description">
													<img class="tg-alignleft" src="./cpp_files/img-07.jpg" alt="image description">
													<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam.</p>
													<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
												</div>
											</div>
										</div>
										<div class="tg-panel">
											<h4>Doloremque laudantium totam rem aperiam, eaque ipsa quae ab illo?</h4>
											<div class="tg-panelcontent" style="display: none;">
												<div class="tg-description">
													<p>Eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco laris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eugiat nulla pariatur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum ut perspictis unde omnis iste natus error sit voluptatem accusantium.</p>
												</div>
											</div>
										</div>
										<div class="tg-panel">
											<h4>Inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo?</h4>
											<div class="tg-panelcontent" style="display: none;">
												<div class="tg-description">
													<img class="tg-alignleft" src="./cpp_files/img-07.jpg" alt="image description">
													<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam.</p>
													<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
												</div>
											</div>
										</div>
										<div class="tg-panel">
											<h4>Nemo enim ipsam voluptatem quia voluptas sit?</h4>
											<div class="tg-panelcontent" style="display: none;">
												<div class="tg-description">
													<p>Eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco laris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eugiat nulla pariatur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum ut perspictis unde omnis iste natus error sit voluptatem accusantium.</p>
												</div>
											</div>
										</div>
										<div class="tg-panel">
											<h4>Nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat?</h4>
											<div class="tg-panelcontent" style="display: none;">
												<div class="tg-description">
													<img class="tg-alignleft" src="./cpp_files/img-07.jpg" alt="image description">
													<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam.</p>
													<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
												</div>
											</div>
										</div>
										<div class="tg-panel">
											<h4>Duis aute irure dolor in reprehenderit in voluptate?</h4>
											<div class="tg-panelcontent" style="display: none;">
												<div class="tg-description">
													<p>Eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco laris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eugiat nulla pariatur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum ut perspictis unde omnis iste natus error sit voluptatem accusantium.</p>
													</div>
											</div>
										</div>
										<div class="tg-panel">
											<h4>Velit esse cillum dolore eu fugiat nulla pariatur?</h4>
											<div class="tg-panelcontent" style="display: none;">
												<div class="tg-description">
													<img class="tg-alignleft" src="./cpp_files/img-07.jpg" alt="image description">
													<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam.</p>
													<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<!--************************************
				Main End
		*************************************-->
		<!--************************************
				Footer Start
		*************************************-->
		<?php include 'php/inc/footer.inc'?>
		<!--************************************
				Footer End
		*************************************-->
	</div>
	<!--************************************
			Wrapper End
	*************************************-->
	<!--************************************
			Search Start
	*************************************-->

	<!--************************************
			Search End
	*************************************-->
	<script src="./cpp_files/jquery-library.js.download"></script>
	<script src="./cpp_files/bootstrap.min.js.download"></script>
	<script src="./cpp_files/js"></script>
	<script src="./cpp_files/customScrollbar.min.js.download"></script>
	<script src="./cpp_files/jquery.easings.min.js.download"></script>
	<script src="./cpp_files/scrolloverflow.min.js.download"></script>
	<script src="./cpp_files/jquery.fullPage.js.download"></script>
	<script src="./cpp_files/jquery.countdown.js.download"></script>
	<script src="./cpp_files/owl.carousel.min.js.download"></script>
	<script src="./cpp_files/isotope.pkgd.js.download"></script>
	<script src="./cpp_files/packery-mode.js.download"></script>
	<script src="./cpp_files/prettyPhoto.js.download"></script>
	<script src="./cpp_files/jquery-ui.js.download"></script>
	<script src="./cpp_files/parallax.js.download"></script>
	<script src="./cpp_files/countTo.js.download"></script>
	<script src="./cpp_files/hoverdir.js.download"></script>
	<script src="./cpp_files/appear.js.download"></script>
	<script src="./cpp_files/gmap3.js.download"></script>
	<script src="./cpp_files/main.js.download"></script>

</body></html>