<?php include 'php/inc/head.inc'?>
<main id="tg-main" class="tg-main tg-haslayout">
			<!--************************************
					Featured Products Start
			*************************************-->
			<section class="tg-haslayout tg-margimtopbottom tg-bglight" style="
    margin-top: 0px;
">
				<div class="container">
				<div class="row" style="
    margin-top:  20px;
    margin-bottom: 40px;
">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="hidden-xs visible-sm visible-md visible-lg">
                                <a id="glavna_slika" href="https://www.limundo.com/VelikaSlika/Samsung-s4mini-i9195-zakljucan/163650077" target="_blank" data-pozovi="163650077">
                    <img class="img-thumbnail img-responsive" src="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650077v800h600.jpg" id="mainImage" title="Samsung s4mini i9195 -zaključan" alt="Samsung s4mini i9195 -zaključan">
                </a>

                <input type="hidden" value="http://www.limundo.com" id="prefixSlikeLimundo"><input type="hidden" value="Samsung-s4mini-i9195-zakljucan" id="NazivPredmeta">                    <div class="row thumbnails-list" style="
    width: 406px;
    padding-top: 6px;
">
                                                    <div class="col-sm-4">
                                <a href="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650069v800h600.jpg" class="" id="data-pozovi-163650069" rel="prettyPhoto[gallery]" title="<a href='//static.limundoslike.com/originalslika_Samsung-s4mini-i9195-zakljucan-163650069.jpg' target='_blank'>Slika u punoj veličini</a>">
                                    <img itemprop="image" id="thumb163650069" class="img-thumbnail img-responsive" src="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650069v80h60.jpg" alt="Samsung s4mini i9195 -zaključan" title="Samsung s4mini i9195 -zaključan">
                                </a>

                                                            </div>
                                                        <div class="col-sm-4">
                                <a href="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650073v800h600.jpg" class="" id="data-pozovi-163650073" rel="prettyPhoto[gallery]" title="<a href='//static.limundoslike.com/originalslika_Samsung-s4mini-i9195-zakljucan-163650073.jpg' target='_blank'>Slika u punoj veličini</a>">
                                    <img itemprop="image" id="thumb163650073" class="img-thumbnail img-responsive" src="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650073v80h60.jpg" alt="Samsung s4mini i9195 -zaključan" title="Samsung s4mini i9195 -zaključan">
                                </a>

                                                            </div>
                                                        <div class="col-sm-4">
                                <a href="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650077v800h600.jpg" class="glavna" id="data-pozovi-163650077" rel="prettyPhoto[gallery]" title="<a href='//static.limundoslike.com/originalslika_Samsung-s4mini-i9195-zakljucan-163650077.jpg' target='_blank'>Slika u punoj veličini</a>">
                                    <img itemprop="image" id="thumb163650077" class="img-thumbnail img-responsive" src="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650077v80h60.jpg" alt="Samsung s4mini i9195 -zaključan" title="Samsung s4mini i9195 -zaključan">
                                </a>

                                                            </div>
                                                        <div class="col-sm-4">
                                <a href="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650081v800h600.jpg" class="" id="data-pozovi-163650081" rel="prettyPhoto[gallery]" title="<a href='//static.limundoslike.com/originalslika_Samsung-s4mini-i9195-zakljucan-163650081.jpg' target='_blank'>Slika u punoj veličini</a>">
                                    <img itemprop="image" id="thumb163650081" class="img-thumbnail img-responsive" src="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650081v80h60.jpg" alt="Samsung s4mini i9195 -zaključan" title="Samsung s4mini i9195 -zaključan">
                                </a>

                                                            </div>
                                                        <div class="col-sm-4">
                                <a href="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650085v800h600.jpg" class="" id="data-pozovi-163650085" rel="prettyPhoto[gallery]" title="<a href='//static.limundoslike.com/originalslika_Samsung-s4mini-i9195-zakljucan-163650085.jpg' target='_blank'>Slika u punoj veličini</a>">
                                    <img itemprop="image" id="thumb163650085" class="img-thumbnail img-responsive" src="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650085v80h60.jpg" alt="Samsung s4mini i9195 -zaključan" title="Samsung s4mini i9195 -zaključan">
                                </a>

                                                            </div>
                                                </div>
                                </div>

                            <div class="visible-xs hidden-sm hidden-md hidden-lg">
                    <div data-ride="carousel" class="carousel slide" id="aukcija-carousel">
                        <div role="listbox" class="carousel-inner">
                                                            <div class="item">
                                    <a href="http://static.limundoslike.com/originalslika_Samsung-s4mini-i9195-zakljucan-163650069.jpg" target="_blank"><img class="img-responsive img-thumbnail" alt="Samsung s4mini i9195 -zaključan" src="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650069v800h600.jpg"></a>
                                </div>
                                                                <div class="item">
                                    <a href="http://static.limundoslike.com/originalslika_Samsung-s4mini-i9195-zakljucan-163650073.jpg" target="_blank"><img class="img-responsive img-thumbnail" alt="Samsung s4mini i9195 -zaključan" src="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650073v800h600.jpg"></a>
                                </div>
                                                                <div class="item">
                                    <a href="http://static.limundoslike.com/originalslika_Samsung-s4mini-i9195-zakljucan-163650077.jpg" target="_blank"><img class="img-responsive img-thumbnail" alt="Samsung s4mini i9195 -zaključan" src="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650077v800h600.jpg"></a>
                                </div>
                                                                <div class="item active left">
                                    <a href="http://static.limundoslike.com/originalslika_Samsung-s4mini-i9195-zakljucan-163650081.jpg" target="_blank"><img class="img-responsive img-thumbnail" alt="Samsung s4mini i9195 -zaključan" src="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650081v800h600.jpg"></a>
                                </div>
                                                                <div class="item next left">
                                    <a href="http://static.limundoslike.com/originalslika_Samsung-s4mini-i9195-zakljucan-163650085.jpg" target="_blank"><img class="img-responsive img-thumbnail" alt="Samsung s4mini i9195 -zaključan" src="./e-aukcije -_files/slikaSamsung-s4mini-i9195-zakljucan-163650085v800h600.jpg"></a>
                                </div>
                                                        </div>
                        <ol class="carousel-indicators">
                                                            <li class="" data-slide-to="0" data-target="#aukcija-carousel"></li>
                                                            <li class="" data-slide-to="1" data-target="#aukcija-carousel"></li>
                                                            <li class="" data-slide-to="2" data-target="#aukcija-carousel"></li>
                                                            <li class="" data-slide-to="3" data-target="#aukcija-carousel"></li>
                                                            <li class="active" data-slide-to="4" data-target="#aukcija-carousel"></li>
                                                    </ol>
                        <a data-slide="prev" role="button" href="http://www/e-aukcije.rs/product/aukcija.php#aukcija-carousel" class="left carousel-control">
                            <span aria-hidden="true" class="glyphicon glyphicon-chevron-left"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a data-slide="next" role="button" href="http://www/e-aukcije.rs/product/aukcija.php#aukcija-carousel" class="right carousel-control">
                            <span aria-hidden="true" class="glyphicon glyphicon-chevron-right"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            

                            <br class="hidden-xs">
                <p id="BrojPoseta">305 pregleda</p>
                
            
            <a id="viber_share" class="viber_share_button pull-left visible-xs" alt="Podeli na viberu" href="https://3p3x.adj.st/?adjust_t=u783g1_kw9yml&amp;adjust_fallback=https%3A%2F%2Fwww.viber.com%2F%3Futm_source%3DPartner%26utm_medium%3DSharebutton%26utm_campaign%3DDefualt&amp;adjust_campaign=Sharebutton&amp;adjust_deeplink=viber%3A%2F%2Fforward%3Ftext%3DPogledaj%2520aukciju%253A%2520%2520https%253A%252F%252Fwww.limundo.com%252Fkupovina%252FMobilni-telefoni%252FMobilni-telefoni%252FSamsung-s4mini-i9195-zakljucan%252F67627213"></a>

                        
                    </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            
            
            <h2 itemprop="name" class="aukcija_heading">
                Samsung s4mini i9195 -zaključan
                            </h2>
            

                        <hr>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            
						<a class="btn btn-default auction-btn" href="http://www/kupovina/Mobilni-telefoni/Mobilni-telefoni/Alcatel-pixi-Pixi-4-5/65988105/UbaciUListuZelja" rel="nofollow">
                        <span class="glyphicon glyphicon-star"></span> Ubaci u listu želja</a>
						
						<a class="btn btn-default auction-btn" href="http://www/kupovina/Mobilni-telefoni/Mobilni-telefoni/Alcatel-pixi-Pixi-4-5/65988105/UbaciUListuZelja" rel="nofollow">
                        <span class="glyphicon glyphicon-star"></span>Aktiviraj podsetnik</a>
                    
                    <div class="clearfix"></div>

                    <table class="table table-aukcija table-clear">
                        <tbody><tr>
                            <td>Broj aukcije:</td>
                            <td style="
    text-align: right;
">65988105</td>
                        </tr>
                        <tr>
                            <td>Preostalo vreme:</td>
                            <td class="counter_polje">
                                                                    <strong id="datum_isteka_aukcije">8 minuta, 58 sekundi</strong>
                                                                        <br>
                                    <small><em>(10. jul 2018, 19:15h)</em></small>

                                                            </td>
                        </tr>
                        <tr>
                            <td>Broj ponuda:</td>
                            <td>
                                <a id="broj_ponuda" href="https://www.limundo.com/kupovina/Mobilni-telefoni/Mobilni-telefoni/Alcatel-pixi-Pixi-4-5/65988105/Ponude">
                                    0 ponuda                                </a>
                                <a class="question-href" data-toggle="popover-bottom" href="http://www/e-aukcije.rs/product/aukcija.php#" data-original-title="" data-content="Kada do kraja aukcije ostane manje od 60 minuta, sistem će početi da odbrojava sekunde.<br> Ukoliko želite da pratite trenutnu cenu i ponude, potrebno je da koristite dugme &quot;<strong>Osveži</strong>&quot;."><span class="glyphicon glyphicon-question-sign"></span></a>
                                                                                                                    <a id="osvezi-btn" onclick="osveziPrikaz();" class="btn btn-sm btn-default osvezi-btn"><span class="glyphicon glyphicon-repeat"></span> Osveži</a>
                                                                                                        </td>
                        </tr>
                    </tbody></table>

                    <table class="table table-aukcija table-nudjenje table-clear" style="
    display: block;
    overflow: hidden;
    margin: 20px 0px;
    background:  white;
    border-radius: 7px;
    padding: 20px;
">
                        <tbody><tr>
                            <td>Aktuelna ponuda:
                            </td>
                            <td><b id="aktuelna_ponuda">RSD 1.50</b></td>
                        </tr>
                                    <tr>
                                    <td>Moja ponuda:</td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="table-nudjenje-biding">
                                        <form id="formMojaPonuda" name="formMojaPonuda" action="http://www/kupovina/Mobilni-telefoni/Mobilni-telefoni/Alcatel-pixi-Pixi-4-5/65988105/Potvrda" method="post">
                                            <div class="input-group">
                                                <input type="hidden" name="minBid" id="minBid" value="4000">
                                                <input name="txtIznos" id="bidValue" type="text" autocomplete="off" placeholder="(min. RSD 1.50)" class="form-control">
                                                <span class="input-group-btn">
                                                    <button type="submit" class="btn btn-success">Licitiraj</button>
                                                </span>
                                            </div>
                                        </form>
                                    </td>
                                </tr>
                        <!--  ako je vise predmeta u lageru, jedan predmet ce biti namenjen za aukciju, a ostatak za opciju kupi odmah-->
                                                            <tr>
                                        <td>
                                            Kupi odmah:
                                            <a href="javascript:;" data-toggle="popover" title="" data-content="Klikom na dugme <span class=&quot;label label-info&quot;>Kupi odmah</span> kupićete ovaj predmet po Kupi odmah ceni bez potrebe da čekate kraj aukcije." data-original-title="Kupi odmah?">
                                                <span class="glyphicon glyphicon-question-sign"></span>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <form name="formKupiOdmah" action="http://www/kupovina/Mobilni-telefoni/Mobilni-telefoni/Alcatel-pixi-Pixi-4-5/65988105/KupiOdmah" class="my_offer" method="post">
                                                <div class="input-group">
                                                    <span class="input-group-addon">6.000 din</span>
                                                                                                        <span class="input-group-btn ko-btn">
                                                        <button type="submit" class="btn btn-info">Kupi odmah</button>
                                                    </span>
                                                </div>
                                            </form>
                                        </td>
                                    </tr>
                                            </tbody></table>

               <!-- START Popust uplate preko VISA kartice -->
                                    <!-- END Popust uplate preko VISA kartice -->

                    <table class="table table-aukcija table-opcije-placanja table-clear">
                        <tbody>
                        
                        <tr>
                            <td>Stanje:</td>
                            <td>Polovno</td>
                        </tr>
                        <tr>
                            <td>Garantni list:</td>
                            <td>
                                Da                            </td>
                        </tr>
                    </tbody></table>

                </div>
                
            </div>
        </div>
    </div>
				</div>
			</section>


		</main>
               </div>
				<?php include 'php/inc/footer.inc'?>
               <script src="js/vendor/jquery-library.js"></script>
               <script src="js/vendor/bootstrap.min.js"></script>

               <script src="js/hoverdir.js"></script>
               <script src="js/appear.js"></script>
               <script src="js/main.js"></script>
            </body>
         </html>