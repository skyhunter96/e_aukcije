<?php include 'php/inc/head.inc'?>
                     <!--************************************
                        Featured Products Start
                        *************************************-->
                     <section class="tg-main-section tg-haslayout">
                        <div class="container">
                           <div class="row">
                              <div class="col-sm-12 col-xs-12">
                                 <div class="tg-sectionhead">
                                    <div class="tg-sectiontitle">
                                       <h2><span>Aktivne aukcije</span>Kupi i uštedi<em></em></h2>
                                       <span class="tg-lighttitle"><span>kupujte i uštedite<br>pomoću e-aukcija</span>
                                    </div>
                                 </div>
                              </div>
                              <div class="tg-featuresproduct tg-randomproducts">
                                 <ul id="tg-filterbale-nav" class="tg-featuresproductnav tg-navfilterbale option-set">
                                    <li><a href="#">Aktivne aukcije</a></li>
                                    <li><a href="#">Buduće aukcije</a></li>
                                    <li><a href="#">Završene aukcije</a></li>
                                 </ul>
                                 <div id="filter-masonry" class="tg-featuredproducts tg-filtermasonry">
                                    <div class="col-sm-4 col-xs-6 shoes tg-productitem">
                                       <div class="tg-product-auctions">
                                          <div class="tg-product-max">MP: RSD79,999.00 | MAX: 7999 RSD | 90%</div>
                                          <div class="tg-product-holder">
                                             <figure><a href="aukcija.php"><img src="http://www/awf.png" alt="image description"></a></figure>
                                             <div class="tg-productcontent">
                                                <div class="tg-producttitle">
                                                   <h3><a href="aukcija.php">50 e-aukcije.rs tokena</a></h3>
                                                </div>
                                                <div class="tg-productprice">
                                                   <span span class="tg-product-time">2h 30m</span>
                                                   <span span class="tg-product-price">RSD 12.20</span>
                                                </div>
                                                <div class="tg-licitator"><span>alekexe</span></div>
                                                <a href="aukcija.php" class="col-sm-12 btn btn-primary active">
                                                Licitiraj odmah
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
									<div class="col-sm-4 col-xs-6 shoes tg-productitem">
                                       <div class="tg-product-auctions">
                                          <div class="tg-product-max">MP: RSD79,999.00 | MAX: 7999 RSD | 90%</div>
                                          <div class="tg-product-holder">
                                             <figure><a href="#"><img src="http://www/awf.png" alt="image description"></a></figure>
                                             <div class="tg-productcontent">
                                                <div class="tg-producttitle">
                                                   <h3><a href="#">50 e-aukcije.rs tokena</a></h3>
                                                </div>
                                                <div class="tg-productprice">
                                                   <span span class="tg-product-time">2h 30m</span>
                                                   <span span class="tg-product-price">RSD 12.20</span>
                                                </div>
                                                <div class="tg-licitator"><span>alekexe</span></div>
                                                <a href="/save/1" class="col-sm-12 btn btn-primary active">
                                                Licitiraj odmah
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-sm-4 col-xs-6 shoes tg-productitem">
                                       <div class="tg-product-auctions">
                                          <div class="tg-product-max">MP: RSD79,999.00 | MAX: 7999 RSD | 90%</div>
                                          <div class="tg-product-holder">
                                             <figure><a href="#"><img src="http://www/awf.png" alt="image description"></a></figure>
                                             <div class="tg-productcontent">
                                                <div class="tg-producttitle">
                                                   <h3><a href="#">50 e-aukcije.rs tokena</a></h3>
                                                </div>
                                                <div class="tg-productprice">
                                                   <span span class="tg-product-time">2h 30m</span>
                                                   <span span class="tg-product-price">RSD 12.20</span>
                                                </div>
                                                <div class="tg-licitator"><span>alekexe</span></div>
                                                <a href="/save/1" class="col-sm-12 btn btn-primary active">
                                                Licitiraj odmah
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>

                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                     <!--************************************
                        Featured Products End
                        *************************************-->
                  </main>
                  <!--************************************
                     Main End
                     *************************************-->
                  <!--************************************
                     Footer Start
                     *************************************-->
                  <?php include'php/inc/footer.inc'?>
                  <!--************************************
                     Footer End
                     *************************************-->
               </div>
               <!--************************************
                  Wrapper End
                  *************************************-->
               <!--************************************
                  Search Start
                  *************************************-->

               <!--************************************
                  Search End
                  *************************************-->
               <script src="js/vendor/jquery-library.js"></script>
               <script src="js/vendor/bootstrap.min.js"></script>

               <script src="js/hoverdir.js"></script>
               <script src="js/appear.js"></script>
               <script src="js/main.js"></script>
            </body>
         </html>