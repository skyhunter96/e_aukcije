<?php $__env->startSection('content'); ?>


  <p><?php echo e($user); ?></p>
  <p><?php echo e($email); ?></p>
  <p><?php echo e($pass); ?></p>
  <p><?php echo e($names); ?></p>
  <p><?php echo e($phone); ?></p>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>