<!DOCTYPE html>

    <html lang="en" dir="ltr">
        <head>
            <meta name="robots" content="noindex">
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

            <title>E-aukcije.rs</title>

            <!-- LINKS -->
            <?php $__env->startSection('appendCss'); ?>
            <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/')); ?>img/favicon.png">
            <link href="<?php echo e(asset('/')); ?>css/admin/style.min.css" rel="stylesheet">
            <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/font-awesome.min.css">
            <link rel="stylesheet" href="//cdn.materialdesignicons.com/2.5.94/css/materialdesignicons.min.css">
            <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
            <?php echo $__env->yieldSection(); ?>
            <!-- ENDLINKS -->
        </head>

            <body>

            <?php if(empty(!session('error'))): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <?php if(empty(!session('success'))): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?> </div>
            <?php endif; ?>

            <?php if(empty(!session('message'))): ?>
                <div class="alert alert-success"><?php echo e(session('message')); ?> </div>
            <?php endif; ?>

            <?php if(empty(!session('status'))): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?> </div>
            <?php endif; ?>

            <div id="main-wrapper" data-layout="horizontal" data-navbarbg="skin1" data-sidebartype="full" data-boxed-layout="boxed">

                <?php echo $__env->make('components.admin.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="page-wrapper" style="display: block;">

                    <?php echo $__env->yieldContent('content'); ?>

                    <?php echo $__env->make('components.admin.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                </div>
            </div>


            <?php $__env->startSection('appendJs'); ?>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/jquery.min.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/popper.min.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/bootstrap.min.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/app.min.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/app.init.horizontal.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/app-style-switcher.horizontal.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/perfect-scrollbar.jquery.min.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/sparkline.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/waves.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/sidebarmenu.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/custom.min.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/raphael.min.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/morris.min.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/datatables.min.js"></script>
            <script src="<?php echo e(asset('/')); ?>pics/product1/test_files/admin/js/dashboard3.js"></script>
            <script>
                $(function() {
                    $('#cc-table').DataTable({});
                });
            </script>
            <?php echo $__env->yieldSection(); ?>

        </body>
    </html>