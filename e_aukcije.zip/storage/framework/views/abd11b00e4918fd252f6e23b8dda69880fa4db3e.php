<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="filter-masonry" class="tg-featuredproducts tg-filtermasonry">
            <div class="col-sm-4 col-xs-6 shoes tg-productitem">
                <div class="tg-product-auctions">

                    <div class="tg-product-holder">
                        <figure><a href="<?php echo e(asset('/auctions/'.$auction->id )); ?>"><img src="http://www/awf.png" alt="image description"></a></figure>
                        <div class="tg-productcontent">
                            <div class="tg-producttitle">
                                <h3><a href="<?php echo e(asset('/auctions/'.$auction->id )); ?>"><?php echo e($auction->name); ?></a></h3>
                            </div>
                            <div class="tg-productprice">
                                <span class="tg-product-time">ISTICE <?php echo e($auction->end_date); ?></span>
                            </div>
                            <a href="<?php echo e(asset('/auction/destroy/'.$auction->id)); ?>" class="col-sm-12 btn btn-primary active">
                                Izbriši
                            </a>
                        </div>
                    </div>
                </div>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>