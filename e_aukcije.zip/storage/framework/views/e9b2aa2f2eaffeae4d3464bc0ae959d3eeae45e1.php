<html><head><style type="text/css"></style><style type="text/css"></style></head><body><table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="full" bgcolor="#ffffff" style="background-color: #ffffff;" data-module="notification_2">
    <tbody><tr>
        <td align="center">
            <!-- Mobile Wrapper -->

            <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="mobile">
                <tbody><tr>
                    <td width="100%" height="100" align="center">
                        <!-- Space -->

                        <table width="400" border="0" cellpadding="0" cellspacing="0" align="center" class="full">
                            <tbody><tr>
                                <td width="100%" height="50">
                                </td>
                            </tr>
                            </tbody></table>
                        <!-- End Space -->

                        <!-- BOX -->

                        <table width="590" border="0" cellpadding="0" cellspacing="0" align="center" class="full" style="-webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px;">
                            <tbody><tr>
                                <td width="100%" style="border-top-right-radius: 5px; border-top-left-radius: 5px; -webkit-box-shadow: 0px 5px 45.9px 5.1px rgba(0, 0, 0, 0.16); -moz-box-shadow: 0px 5px 45.9px 5.1px rgba(0, 0, 0, 0.16); box-shadow:0px 5px 45.9px 5.1px rgba(0, 0, 0, 0.16)">
                                    <!-- SORTABLE -->

                                    <div class="sortable_inner ui-sortable">
                                        <!-- Start Top -->

                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="mobile BG2" bgcolor="#ffffff" style="border-top-right-radius: 6px; border-top-left-radius: 6px; background-image: <?php echo e(asset('/')); ?>pics/bg.jpg;">
                                            <tbody><tr>
                                                <td width="500" valign="middle" align="center" class="fullCenter">
                                                    <!-- Space -->

                                                    <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="mobile">
                                                        <tbody><tr>
                                                            <td width="100%" valign="middle" align="center">
                                                                <table width="300" border="0" cellpadding="0" cellspacing="0" align="center" style="text-align: center; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="fullCenter">
                                                                    <tbody><tr>
                                                                        <td width="100%" height="30" style="font-size: 1px; line-height: 1px;">
                                                                            &nbsp;
                                                                        </td>
                                                                    </tr>
                                                                    </tbody></table>
                                                            </td>
                                                        </tr>
                                                        </tbody></table>
                                                    <!-- Logo -->

                                                    <table width="400" border="0" cellpadding="0" cellspacing="0" align="center" class="fullCenter">
                                                        <tbody><tr>
                                                            <td width="400" style="width:140px; height:auto; " align="center">
                                                                <a href="#" style="text-decoration: none;"><img src="<?php echo e(asset('/')); ?>pics/logo.png" height="40" alt="" border="0" class="hover"></a>
                                                            </td>
                                                        </tr>
                                                        </tbody></table>
                                                    <!-- End Logo -->

                                                    <!-- Space -->

                                                    <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="mobile" style="-webkit-border-bottom-right-radius: 6px; -moz-border-bottom-right-radius: 6px; border-bottom-right-radius: 6px; -webkit-border-bottom-left-radius: 6px; -moz-border-bottom-left-radius: 6px; border-bottom-left-radius: 6px;">
                                                        <tbody><tr>
                                                            <td width="100%" valign="middle" align="center">
                                                                <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" style="text-align: center; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="fullCenter">
                                                                    <tbody><tr>
                                                                        <td width="100%" height="30" style="font-size: 1px; line-height: 1px;">
                                                                            &nbsp;
                                                                        </td>
                                                                    </tr>
                                                                    </tbody></table>
                                                            </td>
                                                        </tr>
                                                        </tbody></table>
                                                </td>
                                            </tr>
                                            </tbody></table>
                                        <table width="500" border="0" cellpadding="0" cellspacing="0" align="center" class="mobile" bgcolor="#ffffff" style="-webkit-border-top-right-radius: 6px; -moz-border-top-right-radius: 6px; border-top-right-radius: 6px; -webkit-border-top-left-radius: 6px; -moz-border-top-left-radius: 6px; border-top-left-radius: 6px;">
                                            <tbody><tr>
                                                <td width="100%" valign="middle" align="center" class="fullCenter">
                                                    <!-- Space -->

                                                    <table width="300" border="0" cellpadding="0" cellspacing="0" align="center" style="text-align: center; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="fullCenter">
                                                        <tbody><tr>
                                                            <td width="100%" height="25" style="font-size: 1px; line-height: 1px;">
                                                                &nbsp;
                                                            </td>
                                                        </tr>
                                                        </tbody></table>
                                                    <!-- title -->

                                                    <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="mobile">
                                                        <tbody><tr>
                                                            <td width="100%" valign="middle" align="center">
                                                                <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" style="text-align: center; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="fullCenter">
                                                                    <tbody><tr>
                                                                        <td valign="middle" width="100%" style="text-align: left; font-family: 'Open Sans', Helvetica, Arial, sans-serif; font-size: 30px; color: #353535; line-height: 37px; font-weight: 300;" class="fullCenter">Registracija je skoro gotova!</td>
                                                                    </tr>
                                                                    </tbody></table>
                                                            </td>
                                                        </tr>
                                                        </tbody></table>
                                                    <!-- Space -->

                                                    <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="mobile" style="-webkit-border-bottom-right-radius: 6px; -moz-border-bottom-right-radius: 6px; border-bottom-right-radius: 6px; -webkit-border-bottom-left-radius: 6px; -moz-border-bottom-left-radius: 6px; border-bottom-left-radius: 6px;">
                                                        <tbody><tr>
                                                            <td width="100%" valign="middle" align="center">
                                                                <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" style="text-align: center; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="fullCenter">
                                                                    <tbody><tr>
                                                                        <td width="100%" height="25" style="font-size: 1px; line-height: 1px;">
                                                                            &nbsp;
                                                                        </td>
                                                                    </tr>
                                                                    </tbody></table>
                                                            </td>
                                                        </tr>
                                                        </tbody></table>
                                                    <!-- Text -->

                                                    <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" style="text-align: center; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                                        <tbody><tr>
                                                            <td valign="middle" width="100%" style="text-align: left; font-family: 'Open Sans', Helvetica, Arial, sans-serif; font-size: 16px; color: #575757; line-height: 26px; font-weight: 300;">Molimo Vas da potvrdite VaÅ¡ imejl da bi aktivirali nalog. Kliknite na dugme "Aktiviraj nalog" za aktivaciju naloga. Ukoliko ne Å¾elite da napravite nalog na ovoj imejl adresi ignoriÅ¡ite ovaj imejl.
                                                                <br><br>
                                                                Pitanje sigurnosti naÅ¡ih korisnika uzimamo vrlo ozbiljno, zbog Äega smo ukljuÄili ovu validaciju e-poÅ¡te. Da biste zavrÅ¡ili registraciju, kliknite na dugme ispod ili pratite link ispod dugmeta.
                                                                <br><br>
                                                                Ukoliko imate nekih pitanja, naÅ¡ tim korisniÄke sluÅ¾be je tu da vam u svakom trenutku pomogne.
                                                            </td>
                                                        </tr>
                                                        </tbody></table>
                                                    <!-- Space -->

                                                    <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" style="text-align: center; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="fullCenter">
                                                        <tbody><tr>
                                                            <td width="100%" height="50" style="font-size: 1px; line-height: 1px;">
                                                                &nbsp;
                                                            </td>
                                                        </tr>
                                                        </tbody></table>
                                                    <!-- Button -->

                                                    <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" style="text-align: center; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                                                        <tbody><tr>
                                                            <td width="100%" align="centre">
                                                                <table border="0" cellpadding="0" cellspacing="0" align="center" class="fullCenter">
                                                                    <tbody><tr>
                                                                        <td align="center" height="50" bgcolor="#eeeeee" style="border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; padding-left: 40px; padding-right: 40px; font-family: 'Open Sans', Helvetica, Arial, sans-serif; color: rgb(0, 0, 0); font-size: 22px; font-weight: 400; line-height: 1px; background-color: #eeeeee;">
                                                                            <a href="<?php echo e(url('user/verify', $user->token)); ?>" style="color: rgb(0, 0, 0); text-decoration: none; width: 100%;">Aktiviraj nalog</a>
                                                                        </td>
                                                                    </tr>
                                                                    </tbody></table>
                                                            </td>
                                                        </tr>
                                                        </tbody></table>
                                                    <!-- Space -->

                                                    <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="mobile" style="-webkit-border-bottom-right-radius: 6px; -moz-border-bottom-right-radius: 6px; border-bottom-right-radius: 6px; -webkit-border-bottom-left-radius: 6px; -moz-border-bottom-left-radius: 6px; border-bottom-left-radius: 6px;">
                                                        <tbody><tr>
                                                            <td width="100%" valign="middle" align="center">
                                                                <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" style="text-align: center; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" class="fullCenter">
                                                                    <tbody><tr>
                                                                        <td width="100%" height="50" style="font-size: 1px; line-height: 1px;">
                                                                            &nbsp;
                                                                        </td>
                                                                    </tr>
                                                                    </tbody></table>
                                                            </td>
                                                        </tr>
                                                        </tbody></table>
                                                </td>
                                            </tr>
                                            </tbody></table>
                                    </div>
                                </td>
                            </tr>
                            </tbody></table>
                        <!-- CopyRight -->

                        <table width="590" border="0" cellpadding="0" cellspacing="0" align="center" class="full">
                            <tbody><tr>
                                <td width="100%" height="30" style="font-size: 1px; line-height: 1px;">
                                    &nbsp;
                                </td>
                            </tr>
                            <tr>
                                <td valign="middle" width="100%" style="text-align: center; font-family: 'Open Sans', Helvetica, Arial, sans-serif; color: rgb(165, 168, 174); font-size: 12px; font-weight: 400; line-height: 18px;" class="fullCenter">
                                    <i>Ovaj automatski imejl vam je poslat od strane sajta e-aukcije.rs<br> zato što vam je nalog <?php echo e($user['user']); ?> registrovan 00/00/0000 na adresi <?php echo e($user['email']); ?> .</i><br></td>
                            </tr>
                            </tbody></table>
                        <table width="352" border="0" cellpadding="0" cellspacing="0" align="center" class="full">
                        </table>
                        <table width="352" border="0" cellpadding="0" cellspacing="0" align="center" class="full">
                            <tbody><tr>
                                <td width="100%" height="60" style="font-size: 1px; line-height: 1px;">
                                    &nbsp;
                                </td>
                            </tr>
                            </tbody></table>
                        <!-- End CopyRight -->

                    </td>
                </tr>
                </tbody></table>
        </td>
    </tr>
    </tbody></table></body></html>