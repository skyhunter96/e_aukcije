<?php $__env->startSection('content'); ?>

    <?php if(empty(!session('message'))): ?>
        <div class="alert alert-danger">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e((isset($user))? asset('/users/update/'.$user->id)  : asset('/users/store')); ?>" method="POST" enctype="multipart/form-data">

        <?php echo e(csrf_field()); ?>


        <div class="form-group">
            <label>Korisnicko ime:</label>
            <input type="text" name="tbUsername" class="form-control" value="<?php echo e((isset($user))? $user->user : old('tbUsername')); ?>"/>
        </div>
        <div class="form-group">
            <label>Lozinka:</label>
            <input type="password" name="tbPass" class="form-control" value="<?php echo e((isset($user))? $user->pass : old('tbPass')); ?>"/>
        </div>
        <div class="form-group">
            <label>Ime i Prezime:</label>
            <input type="text" name="tbNameSurname" class="form-control" value="<?php echo e((isset($user))? $user->name_surname : old('tbNameSurname')); ?>"/>
        </div>
        <div class="form-group">
            <label>E-mail:</label>
            <input type="text" name="tbEmail" class="form-control" value="<?php echo e((isset($user))? $user->email : old('tbEmail')); ?>"/>
        </div>
        <div class="form-group">
            <label>Telefon:</label>
            <input type="text" name="tbPhone" class="form-control" value="<?php echo e((isset($user))? $user->phone : old('tbPhone')); ?>"/>
        </div>
        <div class="form-group">
            <input type="submit" name="addKorisnik" value="<?php echo e((isset($user))? 'Change korisnik' : 'Add korisnik'); ?> " class="btn btn-default" />
        </div>
    </form>

    <table class="table">
        <tr>
            <td>id</td>
            <td>Ime i Prezime</td>
            <td>E-mail</td>
            <td>Telefon</td>
            <td>Username</td>
            <td>Izmeni</td>
            <td>Obriši</td>
        </tr>
        <!-- Prikaz korisnika-->
        <?php if(isset($users)): ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($user->userId); ?> </td>
                    <td> <?php echo e($user->name_surname); ?> </td>
                    <td> <?php echo e($user->email); ?> </td>
                    <td> <?php echo e($user->phone); ?> </td>
                    <td> <?php echo e($user->user); ?> </td>
                    <td> <a href="<?php echo e(asset('/users/'.$user->userId)); ?>">Izmeni</a> </td>
                    <td> <a href="<?php echo e(asset('/users/destroy/'.$user->userId)); ?>">Obriši</a> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>